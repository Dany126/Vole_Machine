
#pragma once

class ProgramCounter {
private:
    int counter;
public:
    ProgramCounter() : counter(0) {}
    void increment() { ++counter; }
    int getCounter() const { return counter; }
    void setCounter(int value) { counter = value; }
    void reset() { counter = 0; }
};

