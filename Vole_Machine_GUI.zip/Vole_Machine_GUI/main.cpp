#include <QApplication>
#include "MachineGUI.h"
#include <QPushButton>
#include <QTextEdit>
#include <QLineEdit>
#include <QWidget>

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);


    MachineGUI window;
    window.resize(800, 600);




    window.setStyleSheet(
        "QMainWindow {"
        "  background-color: #296E7D;"
        "}"
        "QPushButton {"
        "  background-color: #24727F;"
        "  color: white;"
        "  border: 2px solid #227579;"
        "  border-radius: 10px;"
        "  padding: 10px;"
        "  font-size: 19px;"
        "}"
        "QLineEdit, QTextEdit {"
        "  background-color: rgba(255, 255, 255, 0.9);" // Semi-transparent white background
        "  color: #296E7D;"
        "  border: 2px solid #296E7D;"  // Border color matching the primary theme color
        "  border-radius: 5px;"
        "  padding: 10px;"
        "}"
        );


    window.show();

    return app.exec();
}
