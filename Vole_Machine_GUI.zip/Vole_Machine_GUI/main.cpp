#include <QApplication>
#include "MachineGUI.h"
#include <QPushButton>
#include <QTextEdit>
#include <QLineEdit>
#include <QWidget>

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);

    // Create the main GUI window
    MachineGUI window;
    window.resize(800, 600); // Adjust the size as needed

    // Create a central widget with a layout


    window.setStyleSheet(
        "QMainWindow {"
        "  background-color: #296E7D;" // Background color for the main window (previously black)
        "}"
        "QPushButton {"
        "  background-color: #24727F;" // Matching button background color
        "  color: white;"
        "  border: 2px solid #227579;"  // Border color for buttons
        "  border-radius: 10px;"
        "  padding: 10px;"
        "  font-size: 19px;"
        "}"
        "QLineEdit, QTextEdit {"
        "  background-color: rgba(255, 255, 255, 0.9);" // Semi-transparent white background
        "  color: #296E7D;"
        "  border: 2px solid #296E7D;"  // Border color matching the primary theme color
        "  border-radius: 5px;"
        "  padding: 10px;"
        "}"
        );

    // Show the window
    window.show();

    return app.exec();
}
