#pragma once
#include <iostream>
#include <vector>
#include <string>
#include <sstream>
#include "Memory.h"
#include "Registers.h"
#include "Counter.h"
#include "Instruction_Register.h"
#include<bitset>
#include<cmath>
using namespace std;

class Machine {
private:
    ProgramCounter PC;
    InstructionRegister IR;
    vector<string> instructionsList;
    static constexpr int REGISTER_SIZE = 16;

    bool isValidInstruction(const string &instruction) const {
        return !instruction.empty() && instruction.size() == 4;
    }

public:
    Memory M;
    Registers R;
    vector<int> output;

    Machine() {}
    string addFloatingPoint(const string& hex1, const string& hex2) {
        int bias = 4;
        auto hexTobin = [](const string& hexStr) {
            return bitset<8>(stoi(hexStr, nullptr, 16)).to_string();
        };
        auto binToFloat = [bias](const string& binaryStr) {
            int signBit = binaryStr[0] - '0', exponent = stoi(binaryStr.substr(1, 3), nullptr, 2) - bias;
            float mantissa = 0.0;
            for (int i = 0; i < 4; ++i)
                if (binaryStr[4 + i] == '1') mantissa += pow(2, -(i + 1));
            return pow(-1, signBit) * (1 + mantissa) * pow(2, exponent);
        };
        auto floatTobin = [bias](float value) {
            string result(8, '0');
            result[0] = (value < 0) ? '1' : '0'; value = fabs(value);
            int exponent = 0;
            while (value >= 2) { value /= 2; exponent++; }
            while (value < 1) { value *= 2; exponent--; }
            result.replace(1, 3, bitset<3>(exponent + bias).to_string());
            float mantissa = value - 1;
            for (int i = 0; i < 4; ++i) {
                if (mantissa >= pow(2, -(i + 1))) {
                    result[4 + i] = '1';
                    mantissa -= pow(2, -(i + 1));
                }
            }
            return result;
        };
        auto binTohex = [](const string& binaryStr) {
            int hex_result = bitset<8>(binaryStr).to_ulong();
            stringstream ss;
            ss << uppercase << hex << setw(2) << setfill('0') << hex_result;
            return ss.str();
        };
        float resultFloat = binToFloat(hexTobin(hex1)) + binToFloat(hexTobin(hex2));
        return binTohex(floatTobin(resultFloat));
    }

    string displayOutput(int value) const {
        char convertedCharacter = static_cast<char>(value);
        ostringstream oss;
        oss << "Output in ASCII: " << int(convertedCharacter )<< "       Output in Hex: " << hex << value;
        return oss.str();
    }

    void loadInstructions(const vector<string> &instructions) {
        instructionsList = instructions;
        PC.reset();
        cout << "Instructions loaded. Program Counter reset." << endl;
    }

    void execute() {
        while (PC.getCounter() < instructionsList.size()) {
            string instruction = instructionsList[PC.getCounter()];
            PC.increment();
            cout << "Processing instruction: " << instruction << endl;

            if (!isValidInstruction(instruction)) {
                cout << "Invalid instruction: " << instruction << endl;
                continue;
            }

            char opCode = instruction[0];
            int r = (instruction[1] != '0') ? stoi(string(1, instruction[1]), nullptr, 16) : 0;
            string xy = instruction.substr(2, 2);
            cout << "Opcode: " << opCode << ", Register: " << r << ", XY: " << xy << endl;

            switch (opCode) {
            case '1':
                cout << "LOAD from memory address " << xy << " to register R" << r << endl;
                R.setValue(r, stoi(M.load(stoi(xy, nullptr, 16)), nullptr, 16));
                cout << "Register R" << r << " now has value " << R.getValue(r) << endl;
                break;
            case '2':
                cout << "LOAD immediate value " << xy << " to register R" << r << endl;
                R.setValue(r, stoi(xy, nullptr, 16));
                cout << "Register R" << r << " now has value " << R.getValue(r) << endl;
                break;
            case '3':
                if (xy == "00") {
                    cout << "STORE register R" << r << " value to screen" << endl;
                    output.push_back(R.getValue(r));
                } else {
                    cout << "STORE register R" << r << " value " << R.getValue(r) << " to memory address " << xy << endl;
                    M.store(stoi(xy, nullptr, 16), to_string(R.getValue(r)));
                }
                break;
            case '4':
            {
                int s = stoi(string(1, instruction[2]), nullptr, 16);
                cout << "MOVE value from register R" << s << " to register R" << r << endl;
                R.setValue(r, R.getValue(s));
                break;
            }
            case '5':
            {
                int s = stoi(string(1, instruction[2]), nullptr, 16);
                int t = stoi(string(1, instruction[3]), nullptr, 16);
                cout << "ADD register R" << s << " and register R" << t << " into register R" << r << endl;
                R.setValue(r, (R.getValue(s) + R.getValue(t)) % 256); // Assuming 8-bit registers
                cout << "Register R" << r << " now has value " << R.getValue(r) << endl;
                break;
            }
            case '6':
            {
                int s = stoi(string(1, instruction[2]), nullptr, 16);
                int t = stoi(string(1, instruction[3]), nullptr, 16);
                cout << "ADD (floating-point) register R" << s << " and register R" << t << " into register R" << r << endl;
                R.setValue(r, stoi(addFloatingPoint(string(1, instruction[2]),string(1, instruction[3]))));
                cout << "Register R" << r << " now has value " << R.getValue(r) << endl;
                break;
            }
            case 'B':
                cout << "JUMP if register R" << r << " is equal to register R0" << endl;
                if (R.getValue(r) == R.getValue(0)) {
                    PC.setCounter(stoi(xy, nullptr, 16));
                    cout << "Jumped to instruction at address " << xy << endl;
                }
                break;
            case 'C':
                cout << "Program halted." << endl;
                return;
            case 'D':
                cout << "JUMP if register R" << r << " is greater than register R0" << endl;
                if (R.getValue(r) > R.getValue(0)) {
                    PC.setCounter(stoi(xy, nullptr, 16));
                    cout << "Jumped to instruction at address " << xy << endl;
                }
                break;
            case '7':
            {
                int s = stoi(string(1, instruction[2]), nullptr, 16);
                int t = stoi(string(1, instruction[3]), nullptr, 16);
                cout << "Bitwise OR register R" << s << " and register R" << r << " into register R" << r << endl;
                R.setValue(r, R.getValue(r) | R.getValue(s)); // Bitwise OR operation
                cout << "Register R" << r << " now has value " << R.getValue(r) << endl;
                break;
            }
            case '8':
            {
                int s = stoi(string(1, instruction[2]), nullptr, 16);
                int t = stoi(string(1, instruction[3]), nullptr, 16);
                cout << "AND register R" << s << " with register R" << t << " into register R" << r << endl;
                R.setValue(r, R.getValue(s) & R.getValue(t));
                cout << "Register R" << r << " now has value " << R.getValue(r) << endl;
                break;
            }
            case '9':
            {
                int s = stoi(string(1, instruction[2]), nullptr, 16);
                int t = stoi(string(1, instruction[3]), nullptr, 16);
                cout << "XOR register R" << s << " with register R" << t << " into register R" << r << endl;
                R.setValue(r, R.getValue(s) ^ R.getValue(t));
                cout << "Register R" << r << " now has value " << R.getValue(r) << endl;
                break;
            }
            case 'A':
            {
                int x = stoi(string(1, instruction[3]), nullptr, 16);
                cout << "Rotate right register R" << r << " by " << x << " steps" << endl;
                int value = R.getValue(r);
                R.setValue(r, (value >> x) | (value << (REGISTER_SIZE - x)));
                cout << "Register R" << r << " now has value " << R.getValue(r) << endl;
                break;
            }
            default:
                cout << "Unknown opcode: " << opCode << endl;
                break;
            }
        }
    }

    void displayRegisters() {
        R.display();
    }

    void displayMemory() const {
        M.display();
    }

    void displayOutput() const {
        for (const auto &i : output) {
            cout << displayOutput(i) << endl;
        }
    }
};
