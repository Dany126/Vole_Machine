#ifndef MACHINEGUI_H
#define MACHINEGUI_H

#include <QMainWindow>
#include <QPushButton>
#include <QLineEdit>
#include <QListView>
#include <QStringListModel>
#include <QVBoxLayout>
#include <QMessageBox>
#include <vector>
#include "Machine.h"
#include "ui_mainwindow.h"


namespace Ui {
class MainWindow;
}

class MachineGUI : public QMainWindow {
    Q_OBJECT

public:
    explicit MachineGUI(QWidget *parent = nullptr);
    ~MachineGUI();
    void updateDisplay();
    void display_output();
    void loadInstructionsFromFile();
    void addInstruction();
    void executeInstructions();
    void resetMemory();
    void resetRegisters();
     void resetoutput();

private:
    Ui::MainWindow *ui;
    QStringListModel *memoryModel;
    QStringListModel *registersModel;
    QStringListModel *outputModel;
    QLineEdit *inputLineEdit;
    std::vector<std::string> instructionVector;
    Machine machine;

    void showError(const QString &message);
};





#endif // MACHINEGUI_H
