#ifndef MACHINEGUI_H
#define MACHINEGUI_H

#include <QMainWindow>
#include <QPushButton>
#include <QLineEdit>
#include <QListView>
#include <QStringListModel>
#include <QVBoxLayout>
#include <QMessageBox>
#include <vector>
#include "Machine.h"
#include "ui_mainwindow.h"

class MachineGUI : public QMainWindow {
    Q_OBJECT

public:
    explicit MachineGUI(QWidget *parent = nullptr);
    ~MachineGUI();

private:
    Ui::MainWindow *ui;
    QStringListModel *memoryModel;
    QStringListModel *registersModel;
    std::vector<std::string> instructionVector;
    QLineEdit *inputLineEdit;
    Machine machine;  // Declare your Machine instance here

private slots:
    void resetRegisters();
    void resetMemory();
    void loadInstructionsFromFile();
    void executeInstructions();
    void addInstruction();
    void updateDisplay();
    void showError(const QString &message);
};

#endif // MACHINEGUI_H
