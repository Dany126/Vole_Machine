#include "MachineGUI.h"
#include <QFileDialog>
#include <QFile>
#include <QTextStream>
#include <QLabel>
#include <QHBoxLayout>

MachineGUI::MachineGUI(QWidget *parent) : QMainWindow(parent), ui(new Ui::MainWindow) {
    ui->setupUi(this);

    // Initialize models for memory and registers
    memoryModel = new QStringListModel(this);
    registersModel = new QStringListModel(this);
    inputLineEdit = ui->inputLineEdit;  // Ensure this matches your UI

    // Set models to views
    ui->memoryView->setModel(memoryModel);
    ui->registersView->setModel(registersModel);

    // Connect buttons to their respective functions
    connect(ui->loadButton, &QPushButton::clicked, this, &MachineGUI::loadInstructionsFromFile);
    connect(ui->executeButton, &QPushButton::clicked, this, &MachineGUI::executeInstructions);
    connect(ui->addButton, &QPushButton::clicked, this, &MachineGUI::addInstruction);
    connect(ui->clearm, &QPushButton::clicked, this, &MachineGUI::resetMemory);
    connect(ui->clearr, &QPushButton::clicked, this, &MachineGUI::resetRegisters);
}

MachineGUI::~MachineGUI() {
    delete ui;  // Clean up the UI pointer
}

void MachineGUI::loadInstructionsFromFile() {
    QString fileName = QFileDialog::getOpenFileName(this, "Open Instructions File", "", "Text Files (*.txt);;All Files (*)");

    if (!fileName.isEmpty()) {
        QFile file(fileName);
        if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
            showError("Failed to open the file.");
            return;
        }

        // Read lines into a QStringList
        QStringList instructions;
        QTextStream in(&file);
        while (!in.atEnd()) {
            instructions << in.readLine();
        }
        file.close();

        // Convert QStringList to std::vector<std::string>
        std::vector<std::string> instructionVector;
        for (const QString &instruction : instructions) {
            instructionVector.push_back(instruction.toStdString());
        }

        // Load instructions into the machine
        machine.loadInstructions(instructionVector);
        machine.execute();
        updateDisplay();
    }
}

void MachineGUI::addInstruction() {
    QString text = inputLineEdit->text();
    bool isValid = true;

    // Check if each character is a valid hexadecimal digit
    for (const QChar &ch : text) {
        if (!ch.isDigit() && (ch < 'A' || ch > 'F')) {
            isValid = false;
            break;
        }
    }

    if (isValid) {
        instructionVector.push_back(text.toStdString());
        updateDisplay();
        inputLineEdit->clear();
    } else {
        showError("Invalid input. Please enter numbers or capital letters from A to F.");
    }
}


void MachineGUI::executeInstructions() {
    machine.loadInstructions(instructionVector);
    machine.execute();
    updateDisplay();
}

void MachineGUI::resetMemory() {
    machine.M.reset();
    updateDisplay();
}

void MachineGUI::resetRegisters() {
    machine.R.reset();
    updateDisplay();
}

void MachineGUI::updateDisplay() {
    QStringList memoryContents;
    for (int i = 0; i < 256; ++i) {
        memoryContents << QString("Address %1: %2").arg(i, 2, 16, QChar('0')).arg(QString::fromStdString(machine.M.load(i)));
    }
    memoryModel->setStringList(memoryContents);

    QStringList registerContents;
    for (int i = 0; i < 16; ++i) {
        registerContents << QString("R%1: %2").arg(i).arg(machine.R.getValue(i), 2, 16, QChar('0'));
    }
    registersModel->setStringList(registerContents);
}

void MachineGUI::showError(const QString &message) {
    QMessageBox::critical(this, "Error", message);
}
