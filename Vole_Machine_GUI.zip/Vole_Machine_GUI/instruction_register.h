#pragma once
#include<string>
using namespace std;
class InstructionRegister {
private:
    string currentInstruction;
public:
    void load(const string& inst) { currentInstruction = inst; }
    string getInstruction() const { return currentInstruction; }
};
