#pragma once
#include <iostream>
#include <unordered_map>
#include <iomanip>

using namespace std;

class Registers {
private:
    unordered_map<int, int> registers;
    static constexpr int REGISTER_SIZE = 16;

public:
    Registers() {
        for (int i = 0; i < REGISTER_SIZE; ++i) {
            registers[i] = 0;
        }
    }

    int getValue(int index) const {
        return registers.at(index);
    }

    void setValue(int index, int value) {
        registers[index] = value;
    }
    void reset() {
        for (int i = 0; i < REGISTER_SIZE; ++i) {
            registers[i] = 0;
        }
    }

    void display() const {
        cout << "Registers:\n";
        for (size_t i = 0; i < REGISTER_SIZE; ++i) {
            cout << "R" << i << ": " << hex << setw(2) << setfill('0') << registers.at(i) << endl;
        }
    }
};


