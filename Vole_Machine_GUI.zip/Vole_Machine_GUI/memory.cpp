#include "memory.h"

Memory::Memory() {}
