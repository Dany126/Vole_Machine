#include "instruction_register.h"

Instruction_Register::Instruction_Register() {}
